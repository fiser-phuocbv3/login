<!DOCTYPE html>
<html >
    <head>
        <meta charset="UTF-8">
        <title>Login Form</title>
        <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script src="js/index.js"></script>
        <link rel="stylesheet" href="css/style.css">

    </head>

    <body>
        <div id="login">
            <h1>Log in</h1>
            <form name="dangnhap" method="post" action="login"  onsubmit = "return(validate());">
                <input id="id_username" name="username" type="text" placeholder="Username" required/>
                <input id="id_password" name="password" type="password" placeholder="Password" required/>
                <input id="submit" type="submit" value="Log in"/>
                <a href="register">Register</a>
                @if(isset($error))
                    <div style="color: red;margin-top: 10px">
                        {{$error}}
                    </div>
                @endif
            </form>
            
        <div>
        <script>
            function validate()
            {
                $user = $('#id_username').val();
                $pass = $('#id_password').val();
                if($user.length >= 1 && $pass.length >= 1){
                    return true;
                }else{
                    return false;
                }  
            }
        </script>
    </body>
</html>