<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function showWelcome()
	{
		return View::make('hello');
	}

	public function login(){
		$user = Input::get('username');
		$pass = Input::get('password');
		if($user == 'abc' && $pass == '123456'){
			return Redirect::to('helloworld');
		}else{
			return View::make('login', array('error' =>"Tài khoản hoặc mật khẩu sai"));
		}
	}

}
